
# Methods
# __init__(booth_number: int,  capacity: int)
# ⦁	In the __init__ method, all the needed attributes must be set.
# reserve(number_of_people: int)
# ⦁	Calculates the price for reservation, by multiplying the price per person by the number of people.
# The price per person to reserve a open booth is 2.50.
# ⦁	Set the price for reservation and reserve the booth.

from project.booths.booth import Booth


class OpenBooth(Booth):

    def __init__(self, booth_number: int, capacity: int):
        super().__init__(booth_number, capacity)

    def reserve(self, number_of_people: int):

        self.price_for_reservation = 2.50 * number_of_people
        self.is_reserved = True
