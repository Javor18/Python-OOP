# Class PrivateBooth
# In the private_booth.py file, the class PrivateBooth should be implemented. The private booth is a type of booth.
# Methods
# __init__(booth_number: int,  capacity: int)
# ⦁	In the __init__ method, all the needed attributes must be set.
# reserve(number_of_people: int)
# ⦁	Calculates the price for reservation, by multiplying the price per person by the number of people.
# The price per person to reserve a private booth is 3.50.
# ⦁	Set the price for reservation and reserve the booth.

from project.booths.booth import Booth


class PrivateBooth(Booth):

    def __init__(self, booth_number: int, capacity: int):
        super().__init__(booth_number, capacity)

    def reserve(self, number_of_people: int):

        self.price_for_reservation = 3.50 * number_of_people
        self.is_reserved = True
